package com.chenshuo.muduo.example.multiplexer;

public class Event {

}
